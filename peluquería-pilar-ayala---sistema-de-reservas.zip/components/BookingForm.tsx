
// This file is intentionally left blank as its content is now in BookingWidget.tsx
// The build system should handle the rename. If not, this file should be deleted
// and BookingWidget.tsx should be used.
